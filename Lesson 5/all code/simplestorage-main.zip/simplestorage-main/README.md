# Ethers Simple Storage FCC

`Hi!`
